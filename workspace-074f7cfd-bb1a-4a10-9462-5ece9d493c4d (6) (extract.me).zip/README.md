# 🏋️ Evolution Fitness - Sistema Completo de Gestão de Academia

Uma aplicação web completa, minimalista premium estilo Apple, ultra fluida, leve e profissional para a academia Evolution Fitness.

## ✨ Tecnologias Utilizadas

### 🎯 Stack Principal
- **⚡ Next.js 15** - Framework React com App Router
- **📘 TypeScript 5** - Type-safe JavaScript para melhor experiência
- **🎨 Tailwind CSS 4** - Framework CSS utility-first
- **🧩 shadcn/ui** - Componentes de alta qualidade baseados em Radix UI
- **🌈 Framer Motion** - Animações suaves estilo iOS
- **🎨 next-themes** - Tema claro/escuro oficial

### 🔐 Autenticação & Backend
- **🔐 JWT** - Autenticação com tokens seguros
- **🗄️ Prisma** - ORM moderno para Node.js e TypeScript
- **💾 SQLite** - Banco de dados cliente para desenvolvimento

### 🎨 Design & UX
- **🎯 Lucide React** - Biblioteca de ícones consistente
- **📱 Design Responsivo** - Mobile-first com breakpoints otimizados
- **🌙 Tema Completo** - Suporte a light/dark mode em todos os componentes

## 🎯 Características do Projeto

### 🏠 Páginas Públicas
- **Landpage (/)** - Hero premium estilo Apple.com com depoimentos
- **Estrutura (/estrutura)** - Cards limpos com fotos reais da academia
- **Planos (/planos)** - Mensal e Anual (destacado como Popular)
- **Contato (/contato)** - Formulário e integração com WhatsApp
- **Login (/login)** - Autenticação JWT com toast notifications
- **Cadastro (/register)** - Registro com geração automática de Evolution ID

### 🔒 Área Protegida (/menu)
- **Menu Principal** - Dashboard com informações do usuário
- **Metas (/menu/metas)** - CRUD completo de metas com progresso
- **Treinos (/menu/treinos)** - Registro de treinos com vinculação a metas
- **Perfil (/menu/perfil)** - Informações pessoais e conquistas

### 🎨 Estilo Apple
- **Minimalista Absoluto** - Muito espaço em branco/preto
- **Tipografia Premium** - Fontes grandes, leves e elegantes
- **Animações Suaves** - Transições fade, slide, opacity
- **Paleta Cores**:
  - Claro: branco + cinza suave + acentos ciano/verde
  - Escuro: preto profundo + cinzas
  - Botões principais: ciano premium (leve, não saturado)

## 🚀 Configuração Rápida

### 1. Instalar Dependências
```bash
npm install
```

### 2. Configurar Banco de Dados
```bash
# Push do schema para o banco
npm run db:push

# Gerar Prisma Client
npm run db:generate
```

### 3. Variáveis de Ambiente
Crie um arquivo `.env` na raiz:
```env
DATABASE_URL="file:./db/custom.db"
JWT_SECRET="your-secret-key-here"
NODE_ENV="development"
```

### 4. Iniciar Servidor de Desenvolvimento
```bash
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000) para ver a aplicação.

## 📁 Estrutura do Projeto

```
src/
├── app/                    # Next.js App Router
│   ├── api/               # Rotas da API
│   │   ├── login/         # Autenticação
│   │   ├── register/      # Cadastro
│   │   ├── me/           # Dados do usuário
│   │   ├── metas/        # CRUD de metas
│   │   ├── treinos/      # CRUD de treinos
│   │   ├── profile/      # Atualização de perfil
│   │   ├── contact/      # Formulário de contato
│   │   └── logout/       # Logout
│   ├── menu/              # Área protegida
│   │   ├── metas/        # Página de metas
│   │   ├── treinos/      # Página de treinos
│   │   └── perfil/       # Página de perfil
│   ├── estrutura/        # Estrutura da academia
│   ├── planos/           # Planos e preços
│   ├── contato/          # Contato
│   ├── login/            # Login
│   ├── register/         # Cadastro
│   ├── layout.tsx        # Layout principal
│   └── page.tsx          # Landpage
├── components/           # Componentes React
│   ├── ui/              # Componentes shadcn/ui
│   ├── header.tsx       # Header com navegação
│   ├── footer.tsx       # Footer da aplicação
│   └── theme-provider.tsx # Provider de tema
├── hooks/               # Hooks personalizados
├── lib/                 # Utilitários e configurações
│   ├── db.ts           # Cliente Prisma
│   └── utils.ts        # Funções utilitárias
└── app/                # Estilos globais
```

## 🔐 Sistema de Autenticação

### JWT Implementation
- **Login**: Gera token com 7 dias de validade
- **Armazenamento**: Cookie httpOnly seguro
- **Validação**: Middleware protege rotas `/menu/*`
- **Logout**: Remove token e redireciona

### Evolution ID
- **Formato**: `EVF-XXXXXX` (6 dígitos aleatórios)
- **Geração**: Automática no cadastro
- **Exibição**: Perfil e menu principal

### Rotas Protegidas
```typescript
// middleware.ts protege automaticamente:
/menu
/menu/metas
/menu/treinos
/menu/perfil
```

## 🗄️ Modelos Prisma

### User
```typescript
model User {
  id           String   @id @default(cuid())
  name         String
  email        String   @unique
  password     String
  evolutionId  String   @unique
  cpf          String?
  phone        String?
  howKnow      String   @default("Pelo site")
  avatar       String?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
  
  metas        Meta[]
  treinos      Treino[]
}
```

### Meta
```typescript
model Meta {
  id          String   @id @default(cuid())
  title       String
  description String?
  target      Int?
  current     Int      @default(0)
  completed   Boolean  @default(false)
  active      Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  userId      String
  user        User     @relation(fields: [userId], references: [id])
  
  treinos     Treino[]
}
```

### Treino
```typescript
model Treino {
  id           String   @id @default(cuid())
  name         String
  repetitions  Int
  weight       Float?
  notes        String?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
  
  userId       String
  user         User     @relation(fields: [userId], references: [id])
  
  metaId       String?
  meta         Meta?    @relation(fields: [metaId], references: [id])
}
```

## 🎨 Sistema de Temas

### Configuração
```typescript
// tailwind.config.ts
darkMode: "class"

// layout.tsx
<ThemeProvider attribute="class" defaultTheme="system">
```

### Componentes Tematizados
- **Header**: Logo + navegação + toggle tema
- **Footer**: Links sociais + informações
- **Cards**: Adaptação automática light/dark
- **Botões**: Estilo iOS com hover effects

## 📱 Funcionalidades Principais

### 🎯 Sistema de Metas
- **CRUD Completo**: Criar, editar, ativar/desativar, excluir
- **Progresso Visual**: Barras de progresso minimalistas
- **Status**: Concluídas, ativas, pausadas
- **Integração**: Vinculação com treinos

### 🏋️ Sistema de Treinos
- **Registro**: Nome, repetições, peso, observações
- **Vinculação**: Associar a metas existentes
- **Histórico**: Ordenação por data
- **Edição**: Atualizar informações do treino

### 👤 Sistema de Perfil
- **Informações**: Nome, email, Evolution ID
- **Edição**: Atualizar dados pessoais
- **Avatar**: Upload opcional de foto
- **Conquistas**: Sistema de gamificação

## 🚀 Deploy no Vercel

### 1. Preparar Projeto
```bash
# Build para produção
npm run build

# Testar build localmente
npm start
```

### 2. Configurar Vercel
1. Conecte repositório no Vercel
2. Configure variáveis de ambiente:
   - `DATABASE_URL`
   - `JWT_SECRET`
3. Deploy automático

### 3. Configurar Banco de Dados
- Vercel oferece PostgreSQL como add-on
- Atualizar `DATABASE_URL` no dashboard
- Rodar `prisma db push` no ambiente de produção

## 🔄 Como Funciona o Sistema

### Fluxo de Autenticação
1. **Cadastro**: Usuário preenche formulário → gera Evolution ID → cria JWT
2. **Login**: Valida credenciais → gera token → armazena em cookie
3. **Acesso**: Middleware valida token → permite acesso às rotas
4. **Logout**: Remove token → redireciona para login

### Sistema de Notificações
- **shadcn/ui toast** para feedback
- **Sucesso**: Cadastro, login, meta criada
- **Erros**: Validação, backend, rede
- **Sem alerts**: UX moderna e não invasiva

### Sistema de Rotas
```typescript
// Públicas
/                    # Landpage
/login              # Login
/register           # Cadastro
/estrutura          # Estrutura
/planos             # Planos
/contato            # Contato

// Protegidas (middleware)
/menu               # Dashboard
/menu/metas         # Metas
/menu/treinos       # Treinos
/menu/perfil        # Perfil
```

## 🛠️ Scripts Disponíveis

```bash
# Desenvolvimento
npm run dev          # Servidor de desenvolvimento
npm run lint         # ESLint para qualidade de código

# Banco de Dados
npm run db:push      # Push schema para database
npm run db:generate  # Gerar Prisma Client
npm run db:migrate   # Rodar migrações
npm run db:reset     # Resetar database

# Produção
npm run build        # Build otimizado
npm start           # Servidor de produção
```

## 📊 Performance e Otimização

### 🎨 Design System
- **Component Reusable**: Componentes shadcn/ui consistentes
- **Animations**: Framer Motion para 60fps
- **Images**: Otimização automática com Next.js
- **Bundle Splitting**: Code splitting automático

### 🔐 Segurança
- **JWT Tokens**: Assinatura HMAC SHA-256
- **Cookies**: httpOnly, secure, sameSite
- **Input Validation**: Zod schemas no backend
- **SQL Injection**: Proteção Prisma ORM

### 📱 Mobile-First
- **Breakpoints**: sm, md, lg, xl otimizados
- **Touch Targets**: Mínimo 44px para interação
- **Responsive Design**: Adaptação fluida
- **Performance**: Lazy loading e otimização

## 🤝 Contribuição e Desenvolvimento

### 📋 Boas Práticas
- **TypeScript**: Tipagem estrita em todo o código
- **ESLint**: Seguir regras configuradas
- **Componentes**: Reutilizáveis e documentados
- **APIs**: RESTful com tratamento de erros

### 🎯 Próximos Passos
- [ ] Sistema de agendamento de aulas
- [ ] Integração com pagamento
- [ ] App mobile React Native
- [ ] Sistema de nutrição
- [ ] Dashboard administrativo

---

**Desenvolvido com ❤️ para Evolution Fitness**  
*Transformando vidas através do fitness* 💪
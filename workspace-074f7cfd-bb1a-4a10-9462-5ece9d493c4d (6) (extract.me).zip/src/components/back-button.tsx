"use client"

import { useRouter } from 'next/navigation'
import { ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useEffect, useState } from 'react'

export function BackButton() {
  const router = useRouter()
  const [hasHistory, setHasHistory] = useState(false)

  useEffect(() => {
    // Verifica se há histórico de navegação
    if (typeof window !== 'undefined') {
      setHasHistory(window.history.length > 1)
    }
  }, [])

  const handleBack = () => {
    if (hasHistory) {
      router.back()
    } else {
      router.push('/menu')
    }
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={handleBack}
      className="fixed top-20 left-4 z-50 bg-background/80 backdrop-blur-sm border-0 shadow-md hover:bg-background/90 transition-all duration-200"
    >
      <ArrowLeft className="h-4 w-4 mr-2" />
      Voltar
    </Button>
  )
}
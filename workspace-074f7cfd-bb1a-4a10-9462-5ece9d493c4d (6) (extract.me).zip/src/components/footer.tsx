import Link from "next/link"
import Image from "next/image"
import { MapPin, Phone, Mail, Instagram, Facebook, Clock } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-background border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo e informações */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <img 
                src="/evolutionlogo.jpg" 
                alt="Evolution Fitness" 
                className="h-12 w-auto"
              />
            </div>
            <h3 className="text-lg font-semibold mb-2">Evolution Fitness</h3>
            <p className="text-muted-foreground mb-4 max-w-md">
              Academia premium com estrutura completa para musculação, cardio, pilates e fisioterapia.
            </p>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4" />
                <span>Av. Rio Grande do Sul, 807 — Fazenda Vilanova — RS</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>(55) 51 9928-3449</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4" />
                <span>contato@evolutionfitness.com.br</span>
              </div>
            </div>
          </div>

          {/* Horários */}
          <div>
            <h4 className="font-semibold mb-4">Horários</h4>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4" />
                <div>
                  <p>Segunda a Sexta</p>
                  <p>6h às 21h</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4" />
                <div>
                  <p>Sábado</p>
                  <p>7:45 às 11:45</p>
                </div>
              </div>
            </div>
          </div>

          {/* Links e redes sociais */}
          <div>
            <h4 className="font-semibold mb-4">Links Úteis</h4>
            <div className="space-y-2 mb-6">
              <Link href="/estrutura" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Estrutura
              </Link>
              <Link href="/planos" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Planos
              </Link>
              <Link href="/contato" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Contato
              </Link>
            </div>
            
            <h4 className="font-semibold mb-4">Redes Sociais</h4>
            <div className="flex space-x-4">
              <a 
                href="https://instagram.com/evolutionfitness" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="https://facebook.com/evolutionfitness" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-border text-center text-sm text-muted-foreground">
          <p>&copy; 2024 Evolution Fitness. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
"use client"

import { motion } from "framer-motion"
import { Dumbbell, Heart, Brain, Activity } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BackButton } from "@/components/back-button"

export default function EstruturaPage() {
  const structureItems = [
    {
      title: "Musculação",
      description: "Equipamentos modernos e completos para todos os tipos de treino de força. Desde aparelhos para iniciantes até áreas avançadas de levantamento de peso olímpico.",
      icon: Dumbbell,
      image: "/gym-interior.jpg",
      features: [
        "Aparelhos de última geração",
        "Área de peso livre",
        "Barras e halteres variados",
        "Instrutores especializados"
      ]
    },
    {
      title: "Cardio",
      description: "Ampla variedade de equipamentos cardiovasculares para melhorar sua resistência e queimar calorias de forma eficiente e segura.",
      icon: Heart,
      image: "/gym-cardio.jpg",
      features: [
        "Esteiras profissionais",
        "Bicicletas ergométricas",
        "Elípticos e transport",
        "Telas com entretenimento"
      ]
    },
    {
      title: "Pilates",
      description: "Aulas de Pilates solo e equipamentos para fortalecimento do core, melhora da postura e flexibilidade.",
      icon: Brain,
      image: null,
      features: [
        "Aulas em grupo",
        "Instrutores certificados",
        "Equipamentos de qualidade",
        "Horários flexíveis"
      ]
    },
    {
      title: "Fisioterapia",
      description: "Atendimento especializado para reabilitação, prevenção de lesões e tratamento de dores musculoesqueléticas.",
      icon: Activity,
      image: null,
      features: [
        "Fisioterapeutas especializados",
        "Avaliação personalizada",
        "Tratamentos modernos",
        "Acompanhamento contínuo"
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <BackButton />
      <Header />
      
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Nossa <span className="text-cyan-600">Estrutura</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Conheça nossa infraestrutura completa, projetada para oferecer a melhor experiência em fitness e bem-estar
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {structureItems.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="overflow-hidden border-0 shadow-lg h-full">
                  {item.image && (
                    <div className="relative h-64 overflow-hidden">
                      <img 
                        src={item.image} 
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    </div>
                  )}
                  
                  <CardContent className={`p-8 ${!item.image ? 'pt-8' : ''}`}>
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center">
                        <item.icon className="h-6 w-6 text-cyan-600" />
                      </div>
                      <h3 className="text-2xl font-bold">{item.title}</h3>
                    </div>
                    
                    <p className="text-muted-foreground mb-6 leading-relaxed">
                      {item.description}
                    </p>
                    
                    <div className="space-y-3">
                      {item.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center gap-3">
                          <div className="w-2 h-2 bg-cyan-600 rounded-full" />
                          <span className="text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
            className="mt-16"
          >
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Dumbbell className="h-10 w-10 text-cyan-600" />
                </div>
                <h3 className="text-2xl font-bold mb-4">
                  Equipamentos de <span className="text-cyan-600">Alta Qualidade</span>
                </h3>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  Trabalhamos com as melhores marcas do mercado para garantir segurança, conforto e eficiência em todos os seus treinos.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-cyan-600 mb-2">50+</div>
                    <div className="text-sm text-muted-foreground">Aparelhos</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-cyan-600 mb-2">200+</div>
                    <div className="text-sm text-muted-foreground">Alunos</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-cyan-600 mb-2">15+</div>
                    <div className="text-sm text-muted-foreground">Professores</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-cyan-600 mb-2">24/7</div>
                    <div className="text-sm text-muted-foreground">Segurança</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
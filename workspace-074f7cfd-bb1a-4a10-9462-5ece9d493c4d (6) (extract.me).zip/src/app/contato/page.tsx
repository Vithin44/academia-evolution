"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { MapPin, Phone, Mail, Send, MessageCircle, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BackButton } from "@/components/back-button"
import { useToast } from "@/hooks/use-toast"

export default function ContatoPage() {
  const [formData, setFormData] = useState({
    name: "",
    whatsapp: "",
    email: "",
    message: ""
  })
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        toast({
          title: "Mensagem enviada!",
          description: "Entraremos em contato em breve",
        })
        setFormData({ name: "", whatsapp: "", email: "", message: "" })
      } else {
        const data = await response.json()
        toast({
          title: "Erro",
          description: data.error || "Ocorreu um erro ao enviar a mensagem",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao enviar a mensagem",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const contactInfo = [
    {
      icon: MapPin,
      title: "Endereço",
      content: "Av. Rio Grande do Sul, 807<br />Fazenda Vilanova — RS<br />CEP: 95875-000",
      action: null
    },
    {
      icon: Phone,
      title: "Telefone",
      content: "(55) 51 9928-3449",
      action: () => window.open('tel:+5551999283449')
    },
    {
      icon: Mail,
      title: "Email",
      content: "contato@evolutionfitness.com.br",
      action: () => window.open('mailto:contato@evolutionfitness.com.br')
    },
    {
      icon: Clock,
      title: "Horários",
      content: "Seg-Sex: 6h às 21h<br />Sábado: 7:45 às 11:45",
      action: null
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <BackButton />
      <Header />
      
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Entre em <span className="text-cyan-600">Contato</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Estamos prontos para ajudar você a transformar sua vida através do fitness
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl">Envie uma mensagem</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <Label htmlFor="name">Nome completo *</Label>
                      <Input
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Seu nome completo"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="whatsapp">WhatsApp *</Label>
                      <Input
                        id="whatsapp"
                        name="whatsapp"
                        value={formData.whatsapp}
                        onChange={handleChange}
                        placeholder="(00) 00000-0000"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="seu@email.com"
                      />
                    </div>

                    <div>
                      <Label htmlFor="message">Mensagem *</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Como podemos ajudar você?"
                        rows={5}
                        required
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full h-12 bg-cyan-600 hover:bg-cyan-700"
                      disabled={isLoading}
                    >
                      {isLoading ? "Enviando..." : "Enviar mensagem"}
                      <Send className="ml-2 h-4 w-4" />
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="space-y-6"
            >
              {contactInfo.map((info, index) => (
                <Card key={info.title} className="border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center flex-shrink-0">
                        <info.icon className="h-6 w-6 text-cyan-600" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg mb-2">{info.title}</h3>
                        <div 
                          className="text-muted-foreground"
                          dangerouslySetInnerHTML={{ __html: info.content }}
                        />
                        {info.action && (
                          <Button 
                            variant="link" 
                            className="p-0 h-auto text-cyan-600 hover:text-cyan-700 mt-2"
                            onClick={info.action}
                          >
                            Clique aqui
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              <Card className="border-0 shadow-lg bg-green-50 dark:bg-green-900/20">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                      <MessageCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-2">WhatsApp Rápido</h3>
                      <p className="text-muted-foreground mb-3">
                        Fale diretamente com nossa equipe pelo WhatsApp
                      </p>
                      <Button 
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => window.open('https://wa.me/5551999283449?text=Ol%C3%A1!%20Quero%20adquirir%20um%20plano%20na%20Evolution%20Fitness', '_blank')}
                      >
                        <MessageCircle className="mr-2 h-4 w-4" />
                        Falar no WhatsApp
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
          >
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4">
                  Visite nossa <span className="text-cyan-600">Academia</span>
                </h3>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  Venha conhecer nossa estrutura e fazer uma aula experimental. Sem compromisso!
                </p>
                <div className="bg-muted/50 rounded-2xl p-6 max-w-2xl mx-auto">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
                    <div>
                      <h4 className="font-semibold mb-2">O que levar:</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Roupa confortável para treinar</li>
                        <li>• Tênis esportivo</li>
                        <li>• Toalha</li>
                        <li>• Garrafa de água</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Horário das aulas:</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        <li>• Segunda a Sexta: 6h às 21h</li>
                        <li>• Sábado: 7:45 às 11:45</li>
                        <li>• Aulas experimentais gratuitas</li>
                        <li>• Sem necessidade de agendamento</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
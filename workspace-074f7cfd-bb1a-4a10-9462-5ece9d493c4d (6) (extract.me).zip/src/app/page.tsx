"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowRight, Phone, MapPin, Clock, Star, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useAuth } from "@/contexts/auth-context"

export default function Home() {
  const { user, isLoading } = useAuth()

  const neonAnimations = (
    <style jsx>{`
      @keyframes neonPulse {
        0% { filter: drop-shadow(0 0 40px rgba(34,197,94,0.4)); opacity: 0.7; }
        50% { filter: drop-shadow(0 0 60px rgba(34,197,94,1)); opacity: 1; }
        100% { filter: drop-shadow(0 0 40px rgba(34,197,94,0.4)); opacity: 0.7; }
      }

      @keyframes neonFlicker {
        0%, 19%, 21%, 23%, 80%, 100% { opacity: 1; }
        20% { opacity: 0.4; }
        22% { opacity: 0.7; }
        24% { opacity: 0.5; }
      }

      @keyframes strokeGlow {
        0% { text-shadow: 0 0 4px rgba(34,197,94,0.6), 0 0 8px rgba(34,197,94,0.8); }
        50% { text-shadow: 0 0 14px rgba(34,197,94,1), 0 0 24px rgba(34,197,94,1); }
        100% { text-shadow: 0 0 4px rgba(34,197,94,0.6), 0 0 8px rgba(34,197,94,0.8); }
      }

      .glow-outer {
        animation: neonPulse 3s ease-in-out infinite;
      }

      .glow-inner {
        animation: neonPulse 2.4s ease-in-out infinite, neonFlicker 6s infinite;
      }

      .stroke-anim {
        animation: strokeGlow 2.8s ease-in-out infinite, neonFlicker 7s infinite;
      }

      .text-main {
        animation: neonFlicker 8s infinite;
      }
    `}</style>
  )

  const plans = [
    {
      name: "Mensal",
      description: "Acesso completo a todas as estruturas da academia",
      price: "Consultar valor",
      features: [
        "Acesso irrestrito à musculação",
        "Uso de equipamentos de cardio",
        "Acompanhamento básico",
        "Avaliação física inicial",
        "Cancelamento a qualquer momento"
      ],
      highlighted: false,
      popular: false
    },
    {
      name: "Anual",
      description: "Melhor custo-benefício para quem busca resultados a longo prazo",
      price: "Consultar valor",
      features: [
        "Acesso irrestrito à musculação",
        "Uso de equipamentos de cardio",
        "Acompanhamento personalizado",
        "Avaliação física mensal",
        "Desconto exclusivo",
        "Mostre sua disciplina antes mesmo de entrar no treino. Ao escolher o plano anual, você inicia seu compromisso com a evolução desde agora!"
      ],
      highlighted: true,
      popular: true
    }
  ]

  const testimonials = [
    {
      name: "João Silva",
      text: "A melhor academia que já frequentei. Estrutura completa e professores excelentes!",
      rating: 5
    },
    {
      name: "Maria Santos",
      text: "Ambiente limpo, equipamentos modernos e atendimento impecável. Recomendo!",
      rating: 5
    },
    {
      name: "Pedro Costa",
      text: "Transformei meu corpo aqui na Evolution. As aulas de pilates são incríveis!",
      rating: 5
    },
    {
      name: "Ana Oliveira",
      text: "A fisioterapia aqui me ajudou muito na recuperação. Profissionais qualificados.",
      rating: 5
    }
  ]

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Carregando...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {neonAnimations}
      <Header />
      
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-background to-background/90 z-10" />
          <div className="absolute inset-0">
            <img 
              src="/gym-interior.jpg" 
              alt="Evolution Fitness Interior" 
              className="w-full h-full object-cover opacity-20"
            />
          </div>
          
          <div className="relative z-20 text-center px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="relative mb-12 sm:mb-20 md:mb-40 lg:mb-60 flex items-center justify-center px-4">
                <h2 className="relative text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-8xl font-black tracking-[0.05em] sm:tracking-[0.1em] uppercase whitespace-nowrap">
                  {/* Glow Externo - Verde bem grande e suave */}
                  <span className="absolute inset-0 text-green-600/20 blur-xl sm:blur-2xl lg:blur-3xl glow-outer" style={{ 
                    filter: 'drop-shadow(0 0 20px sm:drop-shadow(0 0 30px md:drop-shadow(0 0 40px rgba(34, 197, 94, 0.6))'
                  }}>
                    Evolution Fitness
                  </span>
                  {/* Glow Interno - Super esparso e etéreo */}
                  <span className="absolute inset-0 text-green-600/15 blur-lg sm:blur-xl lg:blur-2xl glow-inner" style={{ 
                    filter: 'drop-shadow(0 0 8px sm:drop-shadow(0 0 12px md:drop-shadow(0 0 16px rgba(34, 197, 94, 0.8))'
                  }}>
                    Evolution Fitness
                  </span>
                  {/* Contorno e sombra principal */}
                  <span className="absolute inset-0 text-green-600 stroke-anim" style={{ 
                    WebkitTextStroke: '2px rgba(34, 197, 94, 0.8)',
                    WebkitTextFillColor: 'transparent',
                    letterSpacing: 'inherit'
                  }}>
                    Evolution Fitness
                  </span>
                  {/* Texto principal */}
                  <span className="relative text-green-600 text-main">
                    Evolution Fitness
                  </span>
                </h2>
              </div>
              <img 
                src="/evolutionlogo.jpg" 
                alt="Evolution Fitness" 
                className="h-16 sm:h-20 lg:h-24 w-auto mx-auto mb-4 sm:mb-6 lg:mb-8"
              />
              <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-7xl font-bold text-foreground mb-4 sm:mb-6">
                Transforme
                <span className="text-cyan-600"> Seu Corpo</span>
              </h1>
              <p className="text-base sm:text-lg md:text-xl lg:text-xl text-muted-foreground mb-6 sm:mb-8 lg:mb-12 max-w-lg sm:max-w-xl lg:max-w-2xl mx-auto px-4">
                Descubra a melhor versão de você mesmo na academia mais completa da região
              </p>
              <div className="flex flex-col gap-3 sm:gap-4 justify-center px-4">
                {!user ? (
                  <>
                    <Link href="/register" className="w-full sm:w-auto">
                      <Button size="lg" className="w-full sm:w-auto bg-cyan-600 hover:bg-cyan-700 text-base sm:text-lg px-4 sm:px-6 lg:px-8 py-2 sm:py-3">
                        Começar Agora
                        <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
                      </Button>
                    </Link>
                    <Link href="/login" className="w-full sm:w-auto">
                      <Button variant="outline" size="lg" className="w-full sm:w-auto text-base sm:text-lg px-4 sm:px-6 lg:px-8 py-2 sm:py-3">
                        Entrar
                      </Button>
                    </Link>
                  </>
                ) : (
                  <Link href="/menu">
                    <Button size="lg" className="w-full sm:w-auto bg-green-600 hover:bg-green-700 text-base sm:text-lg px-4 sm:px-6 lg:px-8 py-2 sm:py-3">
                      Ir para o Menu
                      <ArrowRight className="ml-2 h-4 w-4 sm:h-5 sm:w-5" />
                    </Button>
                  </Link>
                )}
              </div>
            </motion.div>
          </div>
        </section>

        {/* About Section */}
        <section className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16"
            >
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6">
                Sobre a <span className="text-cyan-600">Academia</span>
              </h2>
              <p className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-3xl mx-auto">
                A Evolution Fitness é mais do que uma academia, é um estilo de vida. 
                Com estrutura premium e profissionais qualificados, estamos aqui para 
                ajudar você a alcançar seus objetivos.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="text-center p-4 sm:p-6 border-0 shadow-lg">
                  <CardContent className="pt-4 sm:pt-6">
                    <div className="w-12 h-12 sm:w-16 sm:h-16 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                      <CheckCircle className="h-6 w-6 sm:h-8 sm:w-8 text-cyan-600" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-semibold mb-2">Estrutura Completa</h3>
                    <p className="text-sm sm:text-base text-muted-foreground">
                      Equipamentos modernos e ambiente preparado para todos os tipos de treino
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <Card className="text-center p-4 sm:p-6 border-0 shadow-lg">
                  <CardContent className="pt-4 sm:pt-6">
                    <div className="w-12 h-12 sm:w-16 sm:h-16 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                      <CheckCircle className="h-6 w-6 sm:h-8 sm:w-8 text-cyan-600" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-semibold mb-2">Profissionais Qualificados</h3>
                    <p className="text-sm sm:text-base text-muted-foreground">
                      Equipe de educadores físicos e fisioterapeutas dedicados ao seu sucesso
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                viewport={{ once: true }}
              >
                <Card className="text-center p-4 sm:p-6 border-0 shadow-lg">
                  <CardContent className="pt-4 sm:pt-6">
                    <div className="w-12 h-12 sm:w-16 sm:h-16 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-3 sm:mb-4">
                      <CheckCircle className="h-6 w-6 sm:h-8 sm:w-8 text-cyan-600" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-semibold mb-2">Atendimento Personalizado</h3>
                    <p className="text-sm sm:text-base text-muted-foreground">
                      Planos de treino individualizados e acompanhamento constante
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
          <div className="max-w-6xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16"
            >
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6">
                O Que Nossos <span className="text-cyan-600">Alunos Dizem</span>
              </h2>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6">
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="p-3 sm:p-4 lg:p-6 h-full border-0 shadow-lg">
                    <CardContent className="p-0">
                      <div className="flex mb-2 sm:mb-3 lg:mb-4">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-3 w-3 sm:h-4 sm:w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-xs sm:text-sm lg:text-sm text-muted-foreground mb-2 sm:mb-3 lg:mb-4 italic line-clamp-3">
                        "{testimonial.text}"
                      </p>
                      <p className="text-sm sm:text-base font-semibold">{testimonial.name}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Schedule */}
        <section className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6">
                Nossos <span className="text-cyan-600">Horários</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 lg:gap-8 mt-6 sm:mt-8 lg:mt-12">
                <Card className="p-4 sm:p-6 lg:p-8 border-0 shadow-lg">
                  <CardContent className="p-0 text-center">
                    <Clock className="h-8 w-8 sm:h-10 sm:w-10 lg:h-12 lg:w-12 text-cyan-600 mx-auto mb-3 sm:mb-4" />
                    <h3 className="text-lg sm:text-xl font-semibold mb-2">Segunda a Sexta</h3>
                    <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-cyan-600">6h às 21h</p>
                  </CardContent>
                </Card>
                <Card className="p-4 sm:p-6 lg:p-8 border-0 shadow-lg">
                  <CardContent className="p-0 text-center">
                    <Clock className="h-8 w-8 sm:h-10 sm:w-10 lg:h-12 lg:w-12 text-cyan-600 mx-auto mb-3 sm:mb-4" />
                    <h3 className="text-lg sm:text-xl font-semibold mb-2">Sábado</h3>
                    <p className="text-xl sm:text-2xl lg:text-3xl font-bold text-cyan-600">8h às 12h</p>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Contact */}
        <section className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-8 sm:mb-12 lg:mb-16"
            >
              <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4 sm:mb-6">
                Entre em <span className="text-cyan-600">Contato</span>
              </h2>
              <p className="text-base sm:text-lg lg:text-xl text-muted-foreground mb-6 sm:mb-8 lg:mb-12 max-w-lg sm:max-w-xl lg:max-w-2xl mx-auto">
                Pronto para transformar sua vida? Fale conosco e comece sua jornada hoje mesmo!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/contato">
                  <Button size="lg" className="w-full sm:w-auto bg-cyan-600 hover:bg-cyan-700 text-base sm:text-lg px-4 sm:px-6 lg:px-8 py-2 sm:py-3">
                    Fale Conosco
                  </Button>
                </Link>
                <Link href="/register">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto text-base sm:text-lg px-4 sm:px-6 lg:px-8 py-2 sm:py-3">
                    Matricule-se Já
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
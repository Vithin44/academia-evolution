"use client"

import { motion } from "framer-motion"
import { Check, Star, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BackButton } from "@/components/back-button"

export default function PlanosPage() {
  const plans = [
    {
      name: "Mensal",
      description: "Acesso completo a todas as estruturas da academia",
      price: "Consultar valor",
      features: [
        "Acesso irrestrito à musculação",
        "Uso de equipamentos de cardio",
        "Acompanhamento básico",
        "Avaliação física inicial",
        "Cancelamento a qualquer momento"
      ],
      highlighted: false,
      popular: false
    },
    {
      name: "Anual",
      description: "Melhor custo-benefício para quem busca resultados a longo prazo",
      price: "Consultar valor",
      features: [
        "Acesso irrestrito à musculação",
        "Uso de equipamentos de cardio",
        "Acompanhamento personalizado",
        "Avaliação física mensal",
        "Desconto exclusivo",
        "Mostre sua disciplina antes mesmo de entrar no treino. Ao escolher o plano anual, você inicia seu compromisso com a evolução desde agora!"
      ],
      highlighted: true,
      popular: true
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      <BackButton />
      <Header />
      
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Nossos <span className="text-cyan-600">Planos</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Escolha o plano ideal para transformar seu corpo e alcançar seus objetivos
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {plans.map((plan, index) => (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="relative"
              >
                {plan.highlighted && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10">
                    <div className="bg-cyan-600 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center gap-2">
                      <Star className="h-4 w-4" />
                      Popular
                    </div>
                  </div>
                )}
                
                <Card className={`h-full ${plan.highlighted ? 'border-cyan-600 shadow-2xl scale-105' : 'border-0 shadow-lg'}`}>
                  <CardHeader className="text-center pb-8">
                    <CardTitle className="text-2xl font-bold mb-2">{plan.name}</CardTitle>
                    <p className="text-muted-foreground">{plan.description}</p>
                    <div className="pt-4">
                      <div className="text-3xl font-bold text-cyan-600">{plan.price}</div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <ul className="space-y-4 mb-8">
                      {plan.features.map((feature, featureIndex) => (
                        <li key={featureIndex} className={`flex items-start gap-3 ${feature.includes("Mostre sua disciplina") ? 'items-center justify-center' : ''}`}>
                          {feature.includes("Mostre sua disciplina") ? null : (
                            <Check className="h-5 w-5 text-cyan-600 mt-0.5 flex-shrink-0" />
                          )}
                          <span className={`text-sm ${feature.includes("Mostre sua disciplina") ? 'text-center font-medium italic text-cyan-600 px-4' : ''}`}>
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button 
                      className={`w-full h-12 ${plan.highlighted ? 'bg-cyan-600 hover:bg-cyan-700' : 'bg-background hover:bg-muted border-2 border-cyan-600 text-cyan-600 hover:text-cyan-700'}`}
                      size="lg"
                    >
                      Consultar valor
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            viewport={{ once: true }}
          >
            <Card className="border-0 shadow-lg">
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-4">
                  Dúvidas sobre os planos?
                </h3>
                <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                  Nossa equipe está pronta para ajudar você a escolher o melhor plano para suas necessidades e objetivos.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    size="lg"
                    className="bg-cyan-600 hover:bg-cyan-700"
                    onClick={() => window.open('https://wa.me/5551999283449?text=Ol%C3%A1!%20Quero%20adquirir%20um%20plano%20na%20Evolution%20Fitness', '_blank')}
                  >
                    Falar com consultor
                  </Button>
                  <Button 
                    variant="outline" 
                    size="lg"
                    onClick={() => window.location.href = '/contato'}
                  >
                    Visitar academia
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
            className="mt-16"
          >
            <div className="bg-muted/50 rounded-2xl p-8 text-center">
              <h3 className="text-xl font-semibold mb-6">Por que escolher a Evolution Fitness?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div>
                  <div className="w-12 h-12 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="h-6 w-6 text-cyan-600" />
                  </div>
                  <h4 className="font-semibold mb-2">Sem taxa de matrícula</h4>
                  <p className="text-sm text-muted-foreground">
                    Comece a treinar sem custos adicionais
                  </p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="h-6 w-6 text-cyan-600" />
                  </div>
                  <h4 className="font-semibold mb-2">Flexibilidade total</h4>
                  <p className="text-sm text-muted-foreground">
                    Sem burocracia ou multas rescisórias
                  </p>
                </div>
                <div>
                  <div className="w-12 h-12 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Check className="h-6 w-6 text-cyan-600" />
                  </div>
                  <h4 className="font-semibold mb-2">Suporte completo</h4>
                  <p className="text-sm text-muted-foreground">
                    Equipe preparada para ajudar você
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
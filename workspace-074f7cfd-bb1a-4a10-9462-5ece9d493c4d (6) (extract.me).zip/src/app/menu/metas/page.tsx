"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Plus, Target, Edit2, Trash2, Check, X, TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { BackButton } from "@/components/back-button"
import { useToast } from "@/hooks/use-toast"

interface Meta {
  id: string
  title: string
  description?: string
  target?: number
  current: number
  completed: boolean
  active: boolean
  createdAt: string
}

export default function MetasPage() {
  const [metas, setMetas] = useState<Meta[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [editingMeta, setEditingMeta] = useState<Meta | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    target: "",
    current: "",
    completed: false,
    active: true
  })
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    fetchMetas()
  }, [])

  const fetchMetas = async () => {
    try {
      const response = await fetch('/api/metas')
      if (response.ok) {
        const data = await response.json()
        setMetas(data.metas)
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível carregar suas metas",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const payload = {
      title: formData.title,
      description: formData.description || undefined,
      target: formData.target ? parseInt(formData.target) : undefined
    }

    try {
      const url = editingMeta ? `/api/metas/${editingMeta.id}` : '/api/metas'
      const method = editingMeta ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      })

      if (response.ok) {
        toast({
          title: editingMeta ? "Meta atualizada" : "Meta criada",
          description: editingMeta 
            ? "Sua meta foi atualizada com sucesso"
            : "Sua meta foi criada com sucesso",
        })
        setIsCreateModalOpen(false)
        setEditingMeta(null)
        setFormData({ title: "", description: "", target: "", current: "", completed: false, active: true })
        fetchMetas()
      } else {
        const data = await response.json()
        toast({
          title: "Erro",
          description: data.error || "Ocorreu um erro",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao salvar a meta",
        variant: "destructive",
      })
    }
  }

  const handleEdit = (meta: Meta) => {
    setEditingMeta(meta)
    setFormData({
      title: meta.title,
      description: meta.description || "",
      target: meta.target?.toString() || "",
      current: meta.current.toString(),
      completed: meta.completed,
      active: meta.active
    })
    setIsCreateModalOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir esta meta?")) return

    try {
      const response = await fetch(`/api/metas/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        toast({
          title: "Meta excluída",
          description: "Sua meta foi excluída com sucesso",
        })
        fetchMetas()
      } else {
        toast({
          title: "Erro",
          description: "Não foi possível excluir a meta",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao excluir a meta",
        variant: "destructive",
      })
    }
  }

  const toggleComplete = async (meta: Meta) => {
    try {
      const response = await fetch(`/api/metas/${meta.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ completed: !meta.completed }),
      })

      if (response.ok) {
        toast({
          title: meta.completed ? "Meta reaberta" : "Meta concluída",
          description: meta.completed 
            ? "A meta foi reaberta"
            : "Parabéns! Meta concluída com sucesso",
        })
        fetchMetas()
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar a meta",
        variant: "destructive",
      })
    }
  }

  const toggleActive = async (meta: Meta) => {
    try {
      const response = await fetch(`/api/metas/${meta.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ active: !meta.active }),
      })

      if (response.ok) {
        toast({
          title: meta.active ? "Meta pausada" : "Meta ativada",
          description: meta.active 
            ? "A meta foi pausada"
            : "A meta foi ativada",
        })
        fetchMetas()
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar a meta",
        variant: "destructive",
      })
    }
  }

  const getProgress = (meta: Meta) => {
    if (!meta.target || meta.target === 0) return 0
    return Math.min((meta.current / meta.target) * 100, 100)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Carregando...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <BackButton />
      <Header />
      
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="flex justify-between items-center mb-8"
          >
            <div>
              <h1 className="text-3xl font-bold mb-2">Minhas Metas</h1>
              <p className="text-muted-foreground">Acompanhe e gerencie suas metas de fitness</p>
            </div>
            
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button className="bg-cyan-600 hover:bg-cyan-700">
                  <Plus className="mr-2 h-4 w-4" />
                  Nova Meta
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>
                    {editingMeta ? "Editar Meta" : "Criar Nova Meta"}
                  </DialogTitle>
                  <DialogDescription>
                    {editingMeta ? "Edite os detalhes da sua meta" : "Defina uma nova meta para alcançar"}
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Título *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Ex: Perder 10kg"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Descreva sua meta em detalhes"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="target">Meta (opcional)</Label>
                    <Input
                      id="target"
                      type="number"
                      value={formData.target}
                      onChange={(e) => setFormData({ ...formData, target: e.target.value })}
                      placeholder="Ex: 10 (para 10kg, 10 dias, etc.)"
                    />
                  </div>

                  <Button type="submit" className="w-full bg-cyan-600 hover:bg-cyan-700">
                    {editingMeta ? "Atualizar Meta" : "Criar Meta"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {metas.map((meta, index) => (
              <motion.div
                key={meta.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                <Card className={`h-full ${meta.completed ? 'bg-green-50 dark:bg-green-900/20' : ''} ${!meta.active ? 'opacity-60' : ''}`}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <Target className={`h-5 w-5 ${meta.completed ? 'text-green-600' : 'text-cyan-600'}`} />
                        {meta.title}
                      </CardTitle>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggleActive(meta)}
                          className="h-8 w-8"
                        >
                          {meta.active ? <X className="h-4 w-4" /> : <Check className="h-4 w-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(meta)}
                          className="h-8 w-8"
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(meta.id)}
                          className="h-8 w-8 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    {meta.description && (
                      <p className="text-sm text-muted-foreground mb-4">{meta.description}</p>
                    )}
                    
                    {meta.target && (
                      <div className="mb-4">
                        <div className="flex justify-between text-sm mb-2">
                          <span>Progresso</span>
                          <span>{meta.current} / {meta.target}</span>
                        </div>
                        <Progress value={getProgress(meta)} className="h-2" />
                        <div className="flex justify-between text-xs text-muted-foreground mt-1">
                          <span>{getProgress(meta).toFixed(0)}%</span>
                          {meta.completed && <span className="text-green-600">Concluída! 🎉</span>}
                        </div>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <div className="text-xs text-muted-foreground">
                        {new Date(meta.createdAt).toLocaleDateString('pt-BR')}
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleComplete(meta)}
                        className={meta.completed ? 'text-green-600 border-green-600' : ''}
                      >
                        {meta.completed ? (
                          <>
                            <X className="mr-1 h-3 w-3" />
                            Reabrir
                          </>
                        ) : (
                          <>
                            <Check className="mr-1 h-3 w-3" />
                            Concluir
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {metas.length === 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center py-12"
            >
              <TrendingUp className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Nenhuma meta ainda</h3>
              <p className="text-muted-foreground mb-6">
                Comece definindo suas metas para alcançar seus objetivos de fitness
              </p>
              <Button onClick={() => setIsCreateModalOpen(true)} className="bg-cyan-600 hover:bg-cyan-700">
                <Plus className="mr-2 h-4 w-4" />
                Criar Primeira Meta
              </Button>
            </motion.div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
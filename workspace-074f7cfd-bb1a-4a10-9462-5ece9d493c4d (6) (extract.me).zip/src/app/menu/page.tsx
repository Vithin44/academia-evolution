"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { Target, Dumbbell, User, CreditCard, Phone, LogOut, Trophy, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useAuth } from "@/contexts/auth-context"

export default function MenuPage() {
  const { user, isLoading, logout } = useAuth()

  const menuItems = [
    {
      title: "Metas",
      description: "Gerencie suas metas de fitness",
      icon: Target,
      href: "/menu/metas",
      color: "text-cyan-600"
    },
    {
      title: "Treinos",
      description: "Registre seus treinos",
      icon: Dumbbell,
      href: "/menu/treinos",
      color: "text-cyan-600"
    },
    {
      title: "Perfil",
      description: "Suas informações pessoais",
      icon: User,
      href: "/menu/perfil",
      color: "text-cyan-600"
    },
    {
      title: "Planos",
      description: "Conheça nossos planos",
      icon: CreditCard,
      href: "/planos",
      color: "text-cyan-600"
    },
    {
      title: "Contato",
      description: "Fale conosco",
      icon: Phone,
      href: "/contato",
      color: "text-cyan-600"
    }
  ]

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">Carregando...</div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Acesso não autorizado</h1>
          <p className="text-muted-foreground mb-6">Faça login para acessar esta página</p>
          <Link href="/login">
            <Button className="bg-cyan-600 hover:bg-cyan-700">
              Fazer Login
            </Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <div className="mb-8">
              <div className="w-20 h-20 bg-cyan-100 dark:bg-cyan-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy className="h-10 w-10 text-cyan-600" />
              </div>
              <h1 className="text-4xl font-bold mb-2">Olá, {user.name}!</h1>
              <p className="text-xl text-muted-foreground">Evolution ID: {user.evolutionId}</p>
            </div>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {menuItems.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                <Link href={item.href}>
                  <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-shadow cursor-pointer group">
                    <CardContent className="p-6 text-center">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${item.color} bg-cyan-100 dark:bg-cyan-900 group-hover:scale-110 transition-transform`}>
                        <item.icon className="h-8 w-8" />
                      </div>
                      <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                      <p className="text-muted-foreground">{item.description}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="text-center"
          >
            <Button 
              variant="outline" 
              onClick={logout}
              className="text-red-600 hover:text-red-700 border-red-600 hover:bg-red-50"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Sair da conta
            </Button>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
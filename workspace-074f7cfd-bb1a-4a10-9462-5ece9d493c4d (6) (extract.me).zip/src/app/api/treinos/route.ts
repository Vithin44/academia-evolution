import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import { db } from '@/lib/db'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

async function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get('token')?.value
  if (!token) throw new Error('Não autorizado')
  
  const decoded = jwt.verify(token, JWT_SECRET) as { userId: string }
  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    const userId = await getUserFromToken(request)
    
    const treinos = await db.treino.findMany({
      where: { userId },
      include: {
        meta: {
          select: {
            id: true,
            title: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ treinos })
  } catch (error) {
    console.error('Get treinos error:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar treinos' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const userId = await getUserFromToken(request)
    const { name, repetitions, weight, notes, metaId } = await request.json()

    if (!name || !repetitions) {
      return NextResponse.json(
        { error: 'Nome e repetições são obrigatórios' },
        { status: 400 }
      )
    }

    const treino = await db.treino.create({
      data: {
        name,
        repetitions,
        weight: weight || null,
        notes: notes || null,
        metaId: metaId || null,
        userId
      }
    })

    return NextResponse.json({ treino })
  } catch (error) {
    console.error('Create treino error:', error)
    return NextResponse.json(
      { error: 'Erro ao criar treino' },
      { status: 500 }
    )
  }
}
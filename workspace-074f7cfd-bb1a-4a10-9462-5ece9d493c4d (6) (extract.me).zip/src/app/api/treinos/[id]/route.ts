import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import { db } from '@/lib/db'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

async function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get('token')?.value
  if (!token) throw new Error('Não autorizado')
  
  const decoded = jwt.verify(token, JWT_SECRET) as { userId: string }
  return decoded.userId
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserFromToken(request)
    const { name, repetitions, weight, notes, metaId } = await request.json()
    const { id: treinoId } = await params

    // Verify the treino belongs to the user
    const existingTreino = await db.treino.findFirst({
      where: { id: treinoId, userId }
    })

    if (!existingTreino) {
      return NextResponse.json(
        { error: 'Treino não encontrado' },
        { status: 404 }
      )
    }

    const treino = await db.treino.update({
      where: { id: treinoId },
      data: {
        ...(name !== undefined && { name }),
        ...(repetitions !== undefined && { repetitions }),
        ...(weight !== undefined && { weight }),
        ...(notes !== undefined && { notes }),
        ...(metaId !== undefined && { metaId })
      }
    })

    return NextResponse.json({ treino })
  } catch (error) {
    console.error('Update treino error:', error)
    return NextResponse.json(
      { error: 'Erro ao atualizar treino' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserFromToken(request)
    const { id: treinoId } = await params

    // Verify the treino belongs to the user
    const existingTreino = await db.treino.findFirst({
      where: { id: treinoId, userId }
    })

    if (!existingTreino) {
      return NextResponse.json(
        { error: 'Treino não encontrado' },
        { status: 404 }
      )
    }

    await db.treino.delete({
      where: { id: treinoId }
    })

    return NextResponse.json({ message: 'Treino excluído com sucesso' })
  } catch (error) {
    console.error('Delete treino error:', error)
    return NextResponse.json(
      { error: 'Erro ao excluir treino' },
      { status: 500 }
    )
  }
}
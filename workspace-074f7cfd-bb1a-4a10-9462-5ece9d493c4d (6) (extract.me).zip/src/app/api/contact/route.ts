import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { name, whatsapp, email, message } = await request.json()

    if (!name || !whatsapp || !message) {
      return NextResponse.json(
        { error: 'Nome, WhatsApp e mensagem são obrigatórios' },
        { status: 400 }
      )
    }

    const contato = await db.contato.create({
      data: {
        name,
        whatsapp,
        email: email || null,
        message
      }
    })

    return NextResponse.json({ 
      message: 'Mensagem enviada com sucesso',
      contato 
    })
  } catch (error) {
    console.error('Contact error:', error)
    return NextResponse.json(
      { error: 'Erro ao enviar mensagem' },
      { status: 500 }
    )
  }
}
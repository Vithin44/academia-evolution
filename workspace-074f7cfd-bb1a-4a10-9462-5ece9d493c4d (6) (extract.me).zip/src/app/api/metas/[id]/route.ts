import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import { db } from '@/lib/db'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

async function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get('token')?.value
  if (!token) throw new Error('Não autorizado')
  
  const decoded = jwt.verify(token, JWT_SECRET) as { userId: string }
  return decoded.userId
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserFromToken(request)
    const { title, description, target, current, completed, active } = await request.json()
    const { id: metaId } = await params

    // Verify the meta belongs to the user
    const existingMeta = await db.meta.findFirst({
      where: { id: metaId, userId }
    })

    if (!existingMeta) {
      return NextResponse.json(
        { error: 'Meta não encontrada' },
        { status: 404 }
      )
    }

    const meta = await db.meta.update({
      where: { id: metaId },
      data: {
        ...(title !== undefined && { title }),
        ...(description !== undefined && { description }),
        ...(target !== undefined && { target }),
        ...(current !== undefined && { current }),
        ...(completed !== undefined && { completed }),
        ...(active !== undefined && { active })
      }
    })

    return NextResponse.json({ meta })
  } catch (error) {
    console.error('Update meta error:', error)
    return NextResponse.json(
      { error: 'Erro ao atualizar meta' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserFromToken(request)
    const { id: metaId } = await params

    // Verify the meta belongs to the user
    const existingMeta = await db.meta.findFirst({
      where: { id: metaId, userId }
    })

    if (!existingMeta) {
      return NextResponse.json(
        { error: 'Meta não encontrada' },
        { status: 404 }
      )
    }

    await db.meta.delete({
      where: { id: metaId }
    })

    return NextResponse.json({ message: 'Meta excluída com sucesso' })
  } catch (error) {
    console.error('Delete meta error:', error)
    return NextResponse.json(
      { error: 'Erro ao excluir meta' },
      { status: 500 }
    )
  }
}
import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import { db } from '@/lib/db'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

async function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get('token')?.value
  if (!token) throw new Error('Não autorizado')
  
  const decoded = jwt.verify(token, JWT_SECRET) as { userId: string }
  return decoded.userId
}

export async function GET(request: NextRequest) {
  try {
    const userId = await getUserFromToken(request)
    
    const metas = await db.meta.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ metas })
  } catch (error) {
    console.error('Get metas error:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar metas' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const userId = await getUserFromToken(request)
    const { title, description, target } = await request.json()

    if (!title) {
      return NextResponse.json(
        { error: 'Título é obrigatório' },
        { status: 400 }
      )
    }

    const meta = await db.meta.create({
      data: {
        title,
        description,
        target: target || null,
        userId
      }
    })

    return NextResponse.json({ meta })
  } catch (error) {
    console.error('Create meta error:', error)
    return NextResponse.json(
      { error: 'Erro ao criar meta' },
      { status: 500 }
    )
  }
}
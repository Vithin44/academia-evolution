import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { db } from '@/lib/db'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

function generateEvolutionId() {
  const random = Math.floor(100000 + Math.random() * 900000)
  return `EVF-${random}`
}

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, cpf, phone } = await request.json()

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: 'Nome, email e senha são obrigatórios' },
        { status: 400 }
      )
    }

    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Este email já está cadastrado' },
        { status: 400 }
      )
    }

    const hashedPassword = await bcrypt.hash(password, 10)
    const evolutionId = generateEvolutionId()

    const user = await db.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        evolutionId,
        cpf: cpf || null,
        phone: phone || null,
        howKnow: 'Pelo site'
      }
    })

    const token = jwt.sign(
      { 
        userId: user.id, 
        email: user.email,
        evolutionId: user.evolutionId 
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    )

    const response = NextResponse.json({
      message: 'Cadastro realizado com sucesso',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        evolutionId: user.evolutionId
      },
      token
    })

    response.cookies.set('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    })

    return response
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
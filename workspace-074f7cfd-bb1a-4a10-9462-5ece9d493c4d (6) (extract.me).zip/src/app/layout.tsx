import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/contexts/auth-context";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "Evolution Fitness - Transforme Seu Corpo",
  description: "Academia premium com estrutura completa para musculação, cardio, pilates e fisioterapia.",
  keywords: ["Evolution Fitness", "Academia", "Musculação", "Cardio", "Pilates", "Fisioterapia"],
  authors: [{ name: "Evolution Fitness Team" }],
  openGraph: {
    title: "Evolution Fitness",
    description: "Transforme seu corpo na academia mais completa da região",
    url: "https://evolutionfitness.com.br",
    siteName: "Evolution Fitness",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Evolution Fitness",
    description: "Transforme seu corpo na academia mais completa da região",
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon.ico" />
      </head>
      <body
        className={`${inter.variable} font-sans antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <AuthProvider>
            {children}
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}